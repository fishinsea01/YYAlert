//
//  YYAlert.m
//  AlertView
//
//  Created by user on 16/3/28.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "YYAlert.h"

@interface YYAlert ()<UITextFieldDelegate>
{
    //输入框的内容是否超过6位
    BOOL firstFieldTextLengthOK;
    BOOL secondTextFieldLengthOK;
}
@end

@implementation YYAlert

- (void)viewDidLoad {
    [super viewDidLoad];
    firstFieldTextLengthOK=NO;
    secondTextFieldLengthOK=NO;
}

+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(UIAlertControllerStyle)preferredStyle withTextFieldArray:(NSArray*)textFiledArray withActionButtonArray:(NSArray*)actionArray withActionBlock:(void(^)(NSInteger actionIndex,NSString *loginName,NSString *passWord))actionBlock
{
    YYAlert *alert=nil;
    
    alert=[super alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
    if (alert)
    {
        //输入框内容数组 数组存在则进入此方法 
        if (textFiledArray)
        {
            for (int i=0; i<textFiledArray.count;i++)
            {
                __weak YYAlert *localAlert=alert;
                //获得每个输入框的预输入内容及格式要求
                NSArray *textFiledAttributeArray=textFiledArray[i];
                [alert addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
                    textField.placeholder=textFiledAttributeArray[0];
                    textField.secureTextEntry=[textFiledAttributeArray[1] intValue];
                    textField.tag=i+1;
                    textField.delegate=localAlert;
                    
                }];
            }
        }
        //action内容数组
        if (actionArray)
        {
            for (int i=0;i<actionArray.count;i++)
            {
                //获得每个action的名字及样式
                NSArray *actionAttributeArray=actionArray[i];
                UIAlertAction *action=[UIAlertAction actionWithTitle:actionAttributeArray[0] style:[actionAttributeArray[1] intValue] handler:^(UIAlertAction * _Nonnull action)
                                       {
                                           
                                           if (i<actionArray.count-1)
                                           {
                                               actionBlock(i,nil,nil);
                                           }
                                           else
                                           {
                                               actionBlock(i,alert.textFields.firstObject.text,alert.textFields.lastObject.text);
                                           }
                                       }];
                if (textFiledArray)
                {
                    action.enabled=i==(actionArray.count-1)?NO:YES;
                }
                [alert addAction:action];
            }

        }
        //如果按钮数组，和输入框数组均为空，则出现2s后自动消失
        if (textFiledArray==nil&&actionArray==nil)
        {
            [alert performSelector:@selector(dismissAlert) withObject:nil afterDelay:2.0];
        }
 
    }
    
    return alert;

}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag==1)
    {
        firstFieldTextLengthOK=textField.text.length+1>6?YES:NO;
    }
    else
    {
        secondTextFieldLengthOK=textField.text.length+1>6?YES:NO;
    }
    if (firstFieldTextLengthOK&&secondTextFieldLengthOK)
    {
        UIAlertAction *okAction=self.actions.lastObject;
        okAction.enabled=YES;
    }
   
    return YES;
}
-(void)dismissAlert
{
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
