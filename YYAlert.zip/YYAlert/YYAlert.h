//
//  YYAlert.h
//  AlertView
//
//  Created by user on 16/3/28.
//  Copyright © 2016年 zym. All rights reserved.
//


/*
 *TODO:取消按钮是唯一的，如果您添加了第二个取消按钮，那么你就会得到如下的一个运行时异常
 *按钮显示的次序取决于它们添加到对话框控制器上的次序,根据苹果官方制定的《iOS 用户界面指南》，在拥有两个按钮的对话框中取消按钮应放在左边
 *本类中默认取消按钮放在数组中第一个位置，两个按钮时，ok按钮放在数组中最后一个位置
 */

/*
 *带输入框的提示框
 *以取消按钮作为第一按钮，ok按钮作为最后一个按钮，
 *有输入框时默认用户名长度必须大于6，否则冻结ok按钮
 *按钮个数可根据需要添加
 *输入框个数默认为两个，字符串长度限制，默认加在前两个输入框上，如需要添加多个，需要修改内部代码
 */



#import <UIKit/UIKit.h>

@interface YYAlert : UIAlertController


/*重写方法
 *如果使用输入框必须使用UIAlertControllerStyleAlert样式
 *textFiledArray 内部存放数组，每个数组有两个元素：part1:输入框预输入内容 part2:输入框安全性
 *actionArray  内部存放数组，每个数组有两个元素：part1:action的Title part2:action的样式
 *
 *(void(^)(NSInteger actionIndex,NSString *loginName,NSString *passWord))actionBlock
 *参数:part1:索引值，即在数组中的索引值 用来区分那个按钮被点击了
 *    part2:如果带有输入框，第一个输入框的内容
 *    part3:如果带有输入框，第二个输入框的内容
 *  不带输入框时，默认返回值为nil
 */
+ (instancetype)alertControllerWithTitle:(NSString *)title message:(NSString *)message preferredStyle:(UIAlertControllerStyle)preferredStyle withTextFieldArray:(NSArray*)textFiledArray withActionButtonArray:(NSArray*)actionArray withActionBlock:(void(^)(NSInteger actionIndex,NSString *loginName,NSString *passWord))actionBlock;

@end
