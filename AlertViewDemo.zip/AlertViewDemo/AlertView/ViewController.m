//
//  ViewController.m
//  AlertView
//
//  Created by user on 16/3/28.
//  Copyright © 2016年 zym. All rights reserved.
//

#import "ViewController.h"
#import "YYAlert.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor whiteColor];
    UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem];
    button.frame=CGRectMake(100,60, 100,60);
    button.backgroundColor=[UIColor orangeColor];
    [button setTitle:@"按钮" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
    UIButton *button1=[UIButton buttonWithType:UIButtonTypeSystem];
    button1.frame=CGRectMake(100,160, 100,60);
    button1.backgroundColor=[UIColor orangeColor];
    [button1 setTitle:@"按钮输入框混用" forState:UIControlStateNormal];
    [button1 addTarget:self action:@selector(textFileAndbuttonClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    
    UIButton *button2=[UIButton buttonWithType:UIButtonTypeSystem];
    button2.frame=CGRectMake(100,260, 100,60);
    button2.backgroundColor=[UIColor orangeColor];
    [button2 setTitle:@"2s消失" forState:UIControlStateNormal];
    [button2 addTarget:self action:@selector(showTodismiss) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)btnClick
{
    NSArray *array=@[@[@"不好",@"1"],@[@"为啥？",@"2"],@[@"好",@"0"]];
    YYAlert *alert=[YYAlert alertControllerWithTitle:@"温馨提示" message:@"我是纯纯的按钮" preferredStyle:UIAlertControllerStyleAlert withTextFieldArray:nil withActionButtonArray:array withActionBlock:^(NSInteger actionIndex, NSString *loginName, NSString *passWord) {
        switch (actionIndex) {
            case 0:
            {
                NSLog(@"000-------");
            }
                break;
            case 1:
            {
                NSLog(@"111-------");
                
            }
                break;
            case 2:
            {
                NSLog(@"222-------");
                
            }
                break;
                
            default:
                break;
        }

    }];
    [self presentViewController:alert animated:YES completion:nil];
}
-(void)textFileAndbuttonClick
{
    NSArray *textFieldArray=@[@[@"账号",@"0"],@[@"密码",@"1"]];
    NSArray *actionArray=@[@[@"忘了？退出",@"1"],@[@"确定",@"0"]];
    YYAlert *alert=[YYAlert alertControllerWithTitle:@"温馨提示" message:@"账号密码是多少......" preferredStyle:UIAlertControllerStyleAlert withTextFieldArray:textFieldArray withActionButtonArray:actionArray withActionBlock:^(NSInteger actionIndex, NSString *loginName, NSString *passWord) {
        switch (actionIndex) {
            case 0:
            {
                NSLog(@"退出");
            }
                break;
            case 1:
            {
                NSLog(@"账号－－%@--密码－－－－%@",loginName,passWord);
            }
                break;
            default:
                break;
        }
    }];
    [self presentViewController:alert animated:YES completion:nil];

}
-(void)showTodismiss
{
    YYAlert *alert=[YYAlert alertControllerWithTitle:@"看我，快看" message:@"不用点我，自己会消失" preferredStyle:UIAlertControllerStyleAlert withTextFieldArray:nil withActionButtonArray:nil withActionBlock:nil];
    alert.view.backgroundColor=[UIColor purpleColor];
    [self presentViewController:alert animated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
