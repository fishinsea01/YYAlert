//
//  ViewController.h
//  AlertView
//
//  Created by user on 16/3/28.
//  Copyright © 2016年 zym. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

